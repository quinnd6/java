 To run the application please run the jar file in build\libs and on 
your browser go to localhost:8080/