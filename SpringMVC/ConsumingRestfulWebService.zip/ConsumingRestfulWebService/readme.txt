To run the application
open the command line and cd to the ConsumingRestfulWebService directory and type
java -jar build/libs/gs-consuming-rest-0.1.0.jar