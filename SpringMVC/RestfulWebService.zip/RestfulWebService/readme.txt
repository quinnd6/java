To run the application you need to run  gs-rest-service-0.1.0.jar file
You can do this by typing 
java -jar target/gs-rest-service-0.1.0.jar
on the command line from the RestfulWebService directory.
Then on a browser to run it type
http://localhost:8080/greeting
or
http://localhost:8080/greeting?name=John
You can pick any random name and it will print it after "Hello , "
 