//Spring tutorial 04
package org.koushik.javabrains;

public class Triangle {
	
	public void draw(){
		System.out.println("Triangle Drawn");
	}

}
