To run the application
open the command line and cd to the JDBCSpring directory and type
java -jar build/libs/gs-relational-data-access-0.1.0.jar