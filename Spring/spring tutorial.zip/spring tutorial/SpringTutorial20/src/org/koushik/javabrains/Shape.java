//Spring Tutorial 20 - Some JSR-250 Annotations
package org.koushik.javabrains;

public interface Shape {
	public void draw();

}
