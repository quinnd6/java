//Spring Tutorial 32 - Around Advice Type 
package org.koushik.javabrains.model;

public class Triangle {
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
