//Spring Tutorial 22 - Using MessageSource To Get Text From Property Files 
package org.koushik.javabrains;

public interface Shape {
	public void draw();

}
