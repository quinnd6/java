//Spring Tutorial 31 - After Advice Types 
package org.koushik.javabrains.model;

public class Triangle {
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
