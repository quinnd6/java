//Spring Tutorial 19 - The Autowired Annotation 
package org.koushik.javabrains;

public interface Shape {
	public void draw();

}
