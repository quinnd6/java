//Spring Tutorial 23 - Event Handling in Spring
package org.koushik.javabrains;

public interface Shape {
	public void draw();

}
