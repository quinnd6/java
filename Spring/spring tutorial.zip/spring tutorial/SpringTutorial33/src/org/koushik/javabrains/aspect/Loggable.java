package org.koushik.javabrains.aspect;

public @interface Loggable {

}
