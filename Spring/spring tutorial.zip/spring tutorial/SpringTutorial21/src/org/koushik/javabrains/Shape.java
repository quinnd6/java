//Spring Tutorial 21 - Component and Stereotype Annotations 
package org.koushik.javabrains;

public interface Shape {
	public void draw();

}
