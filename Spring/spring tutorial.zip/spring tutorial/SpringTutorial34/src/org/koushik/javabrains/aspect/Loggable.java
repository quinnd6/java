//Spring Tutorial 34 - AOP XML configuration 
package org.koushik.javabrains.aspect;

public @interface Loggable {

}
